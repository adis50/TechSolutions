﻿using System;
using System.Collections.Generic;
using CapaDatos;
using CapaEntidad;

namespace CapaNegocio
{
    public class VentaBL
    {
        public string RegistrarVenta(Venta v)
        {
            if (v.IdCliente <= 0) return "Seleccione un cliente válido.";
            if (v.Detalles == null || v.Detalles.Count == 0) return "La venta debe tener al menos un producto.";

            try
            {
                // Se invoca el método transaccional (ejecuta Commit o Rollback si falla)
                VentaDAO.Instancia.RegistrarVentaTransaccional(v);
                return "";
            }
            catch (Exception ex)
            {
                return "Error en la transacción (Rollback ejecutado): " + ex.Message;
            }
        }

        public List<Venta> ReporteVentas(DateTime inicio, DateTime fin)
        {
            return VentaDAO.Instancia.ReporteVentasPorFecha(inicio, fin);
        }
    }
}