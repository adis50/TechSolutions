﻿using System;
using System.Data.SqlClient;
using CapaEntidad;

namespace CapaDatos
{
    public class UsuarioDAO
    {
        private static readonly UsuarioDAO _instancia = new UsuarioDAO();
        public static UsuarioDAO Instancia => _instancia;
        private UsuarioDAO() { }

        public Usuario ValidarAcceso(string usuario, string clave, string hardwareActual, out string mensaje)
        {
            mensaje = "";
            using (SqlConnection cn = Conexion.Instancia.ObtenerConexion())
            {
                string sql = "SELECT IdUsuario, NombreUsuario, NombreCompleto, Rol, HardwareId, Activo " +
                             "FROM Usuario WHERE NombreUsuario = @user AND Clave = @pass AND Activo = 1";
                SqlCommand cmd = new SqlCommand(sql, cn);
                cmd.Parameters.AddWithValue("@user", usuario);
                cmd.Parameters.AddWithValue("@pass", clave);

                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Usuario u = new Usuario
                    {
                        IdUsuario = Convert.ToInt32(dr["IdUsuario"]),
                        NombreUsuario = dr["NombreUsuario"].ToString(),
                        NombreCompleto = dr["NombreCompleto"].ToString(),
                        Rol = dr["Rol"].ToString(),
                        HardwareId = dr["HardwareId"] == DBNull.Value ? null : dr["HardwareId"].ToString(),
                        Activo = Convert.ToBoolean(dr["Activo"])
                    };
                    dr.Close();

                    // Si aún no tiene hardware registrado, lo vincula automáticamente
                    if (string.IsNullOrEmpty(u.HardwareId))
                    {
                        SqlCommand cmdUpd = new SqlCommand("UPDATE Usuario SET HardwareId = @hw WHERE IdUsuario = @id", cn);
                        cmdUpd.Parameters.AddWithValue("@hw", hardwareActual);
                        cmdUpd.Parameters.AddWithValue("@id", u.IdUsuario);
                        cmdUpd.ExecuteNonQuery();
                        u.HardwareId = hardwareActual;
                    }
                    else if (u.HardwareId != hardwareActual)
                    {
                        mensaje = "Acceso denegado: este usuario está vinculado a otro equipo (Hardware ID distinto).";
                        return null;
                    }

                    return u;
                }
            }
            mensaje = "Usuario o contraseña incorrectos.";
            return null;
        }
    }
}