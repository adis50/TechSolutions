﻿using System.Windows;
using CapaEntidad;
using CapaNegocio;
using CapaSoporte;

namespace CapaPresentacion.Vistas
{
    public partial class LoginWindow : Window
    {
        private readonly UsuarioBL _usuarioBL = new UsuarioBL();

        public LoginWindow()
        {
            InitializeComponent();
        }

        private void BtnIngresar_Click(object sender, RoutedEventArgs e)
        {
            string user = txtUsuario.Text.Trim();
            string pass = txtClave.Password.Trim();

            Usuario u = _usuarioBL.IniciarSesion(user, pass, out string mensaje);

            if (u != null)
            {
                SesionActual.UsuarioLogueado = u;
                MessageBox.Show($"Bienvenido, {u.NombreCompleto} [{u.Rol}]", "Acceso Concedido", MessageBoxButton.OK, MessageBoxImage.Information);

                MainWindow principal = new MainWindow();
                principal.Show();
                this.Close();
            }
            else
            {   
                MessageBox.Show(mensaje, "Error de Autenticación", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}