﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using CapaEntidad;

namespace CapaDatos
{
    public class ClienteDAO
    {
        private static readonly ClienteDAO _instancia = new ClienteDAO();
        public static ClienteDAO Instancia => _instancia;
        private ClienteDAO() { }

        public List<Cliente> Listar()
        {
            List<Cliente> lista = new List<Cliente>();
            using (SqlConnection cn = Conexion.Instancia.ObtenerConexion())
            {
                string sql = "SELECT IdCliente, Documento, Nombres, Telefono, Correo, Activo FROM Cliente WHERE Activo = 1 ORDER BY IdCliente DESC";
                SqlCommand cmd = new SqlCommand(sql, cn);
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    lista.Add(new Cliente
                    {
                        IdCliente = Convert.ToInt32(dr["IdCliente"]),
                        Documento = dr["Documento"].ToString(),
                        Nombres = dr["Nombres"].ToString(),
                        Telefono = dr["Telefono"].ToString(),
                        Correo = dr["Correo"].ToString(),
                        Activo = Convert.ToBoolean(dr["Activo"])
                    });
                }
            }
            return lista;
        }

        public void Insertar(Cliente c)
        {
            using (SqlConnection cn = Conexion.Instancia.ObtenerConexion())
            {
                string sql = "INSERT INTO Cliente (Documento, Nombres, Telefono, Correo, Activo) VALUES (@doc, @nom, @tel, @cor, 1)";
                SqlCommand cmd = new SqlCommand(sql, cn);
                cmd.Parameters.AddWithValue("@doc", c.Documento);
                cmd.Parameters.AddWithValue("@nom", c.Nombres);
                cmd.Parameters.AddWithValue("@tel", c.Telefono ?? "");
                cmd.Parameters.AddWithValue("@cor", c.Correo ?? "");
                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}