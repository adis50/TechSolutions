﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using CapaEntidad;

namespace CapaDatos
{
    public class ProductoDAO
    {
        private static readonly ProductoDAO _instancia = new ProductoDAO();
        public static ProductoDAO Instancia => _instancia;
        private ProductoDAO() { }

        public List<Producto> Listar()
        {
            List<Producto> lista = new List<Producto>();
            using (SqlConnection cn = Conexion.Instancia.ObtenerConexion())
            {
                string sql = "SELECT IdProducto, Codigo, Nombre, Categoria, Precio, Stock, Activo FROM Producto WHERE Activo = 1 ORDER BY IdProducto DESC";
                SqlCommand cmd = new SqlCommand(sql, cn);
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    lista.Add(new Producto
                    {
                        IdProducto = Convert.ToInt32(dr["IdProducto"]),
                        Codigo = dr["Codigo"].ToString(),
                        Nombre = dr["Nombre"].ToString(),
                        Categoria = dr["Categoria"].ToString(),
                        Precio = Convert.ToDecimal(dr["Precio"]),
                        Stock = Convert.ToInt32(dr["Stock"]),
                        Activo = Convert.ToBoolean(dr["Activo"])
                    });
                }
            }
            return lista;
        }

        public void Insertar(Producto p)
        {
            using (SqlConnection cn = Conexion.Instancia.ObtenerConexion())
            {
                string sql = "INSERT INTO Producto (Codigo, Nombre, Categoria, Precio, Stock, Activo) VALUES (@cod, @nom, @cat, @pre, @stk, @act)";
                SqlCommand cmd = new SqlCommand(sql, cn);
                cmd.Parameters.AddWithValue("@cod", p.Codigo);
                cmd.Parameters.AddWithValue("@nom", p.Nombre);
                cmd.Parameters.AddWithValue("@cat", p.Categoria);
                cmd.Parameters.AddWithValue("@pre", p.Precio);
                cmd.Parameters.AddWithValue("@stk", p.Stock);
                cmd.Parameters.AddWithValue("@act", p.Activo);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public List<Producto> ReporteStockCritico(int stockMaximo)
        {
            List<Producto> lista = new List<Producto>();
            using (SqlConnection cn = Conexion.Instancia.ObtenerConexion())
            {
                SqlCommand cmd = new SqlCommand("sp_ReporteProductosStock", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@StockMaximo", stockMaximo);
                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    lista.Add(new Producto
                    {
                        IdProducto = Convert.ToInt32(dr["IdProducto"]),
                        Codigo = dr["Codigo"].ToString(),
                        Nombre = dr["Nombre"].ToString(),
                        Categoria = dr["Categoria"].ToString(),
                        Precio = Convert.ToDecimal(dr["Precio"]),
                        Stock = Convert.ToInt32(dr["Stock"])
                    });
                }
            }
            return lista;
        }
    }
}