﻿using System.Collections.Generic;
using System.Linq;
using CapaDatos;
using CapaEntidad;

namespace CapaNegocio
{
    public class ProductoBL
    {
        public List<Producto> Listar(string filtro)
        {
            var lista = ProductoDAO.Instancia.Listar();

            // Uso de LINQ para buscar por nombre o categoría de manera flexible
            if (!string.IsNullOrWhiteSpace(filtro))
            {
                lista = lista.Where(p => p.Nombre.ToLower().Contains(filtro.ToLower()) ||
                                         p.Categoria.ToLower().Contains(filtro.ToLower())).ToList();
            }

            return lista;
        }

        public string Registrar(Producto p)
        {
            if (string.IsNullOrWhiteSpace(p.Codigo)) return "Ingrese el código del producto.";
            if (string.IsNullOrWhiteSpace(p.Nombre)) return "Ingrese el nombre del producto.";
            if (p.Precio <= 0) return "El precio debe ser mayor a 0.";

            ProductoDAO.Instancia.Insertar(p);
            return "";
        }

        public List<Producto> ReporteStockCritico(int stockMaximo)
        {
            return ProductoDAO.Instancia.ReporteStockCritico(stockMaximo);
        }
    }
}