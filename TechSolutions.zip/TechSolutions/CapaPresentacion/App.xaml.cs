﻿using System.Windows;
using CapaPresentacion.Vistas;

namespace CapaPresentacion
{
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            LoginWindow login = new LoginWindow();
            login.Show();
        }
    }
}