﻿using CapaDatos;
using CapaEntidad;
using CapaSoporte;

namespace CapaNegocio
{
    public class UsuarioBL
    {
        public Usuario IniciarSesion(string usuario, string clave, out string mensaje)
        {
            if (string.IsNullOrWhiteSpace(usuario) || string.IsNullOrWhiteSpace(clave))
            {
                mensaje = "Ingrese usuario y contraseña.";
                return null;
            }

            string hardwareActual = HardwareHelper.ObtenerHardwareId();
            return UsuarioDAO.Instancia.ValidarAcceso(usuario, clave, hardwareActual, out mensaje);
        }
    }
}