﻿using System.Data.SqlClient;

namespace CapaDatos
{
    public sealed class Conexion
    {
        private static Conexion _instancia;

        private readonly string _cadena =
            "Server=localhost\\SQLEXPRESS01; Database=BDTechSolutions; Integrated Security=true; TrustServerCertificate=true";

        private Conexion() { }

        public static Conexion Instancia
        {
            get
            {
                if (_instancia == null)
                    _instancia = new Conexion();
                return _instancia;
            }
        }

        public SqlConnection ObtenerConexion()
        {
            return new SqlConnection(_cadena);
        }
    }
}