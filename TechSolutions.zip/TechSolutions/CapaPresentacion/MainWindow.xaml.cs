﻿using System.Windows;
using CapaPresentacion.Vistas;
using CapaSoporte;

namespace CapaPresentacion
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.Title = $"Tech Solutions - Usuario: {SesionActual.UsuarioLogueado?.NombreCompleto} ({SesionActual.UsuarioLogueado?.Rol})";
        }

        private void Productos_Click(object sender, RoutedEventArgs e)
        {
            ProductoWindow ventana = new ProductoWindow();
            ventana.Owner = this;
            ventana.ShowDialog();
        }

        private void Ventas_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Módulo de ventas transaccionales listo para conectar.", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Salir_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}