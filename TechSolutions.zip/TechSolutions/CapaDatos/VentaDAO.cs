﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using CapaEntidad;

namespace CapaDatos
{
    public class VentaDAO
    {
        private static readonly VentaDAO _instancia = new VentaDAO();
        public static VentaDAO Instancia => _instancia;
        private VentaDAO() { }

        public void RegistrarVentaTransaccional(Venta v)
        {
            using (SqlConnection cn = Conexion.Instancia.ObtenerConexion())
            {
                cn.Open();
                SqlTransaction tx = cn.BeginTransaction();

                try
                {
                    // 1. Insertar cabecera de Venta y recuperar IdVenta generado
                    string sqlVenta = "INSERT INTO Venta (NumeroComprobante, Fecha, IdCliente, IdUsuario, Total, Estado) " +
                                      "OUTPUT INSERTED.IdVenta VALUES (@num, GETDATE(), @cli, @usu, @tot, 'EMITIDA')";
                    SqlCommand cmdVenta = new SqlCommand(sqlVenta, cn, tx);
                    cmdVenta.Parameters.AddWithValue("@num", v.NumeroComprobante);
                    cmdVenta.Parameters.AddWithValue("@cli", v.IdCliente);
                    cmdVenta.Parameters.AddWithValue("@usu", v.IdUsuario);
                    cmdVenta.Parameters.AddWithValue("@tot", v.Total);

                    int idVentaGenerado = Convert.ToInt32(cmdVenta.ExecuteScalar());

                    // 2. Insertar cada detalle y descontar stock verificando disponibilidad
                    foreach (DetalleVenta d in v.Detalles)
                    {
                        string sqlDet = "INSERT INTO DetalleVenta (IdVenta, IdProducto, Cantidad, PrecioUnitario, Subtotal) " +
                                        "VALUES (@idV, @idP, @cant, @pre, @sub)";
                        SqlCommand cmdDet = new SqlCommand(sqlDet, cn, tx);
                        cmdDet.Parameters.AddWithValue("@idV", idVentaGenerado);
                        cmdDet.Parameters.AddWithValue("@idP", d.IdProducto);
                        cmdDet.Parameters.AddWithValue("@cant", d.Cantidad);
                        cmdDet.Parameters.AddWithValue("@pre", d.PrecioUnitario);
                        cmdDet.Parameters.AddWithValue("@sub", d.Subtotal);
                        cmdDet.ExecuteNonQuery();

                        string sqlStock = "UPDATE Producto SET Stock = Stock - @cant WHERE IdProducto = @idP AND Stock >= @cant";
                        SqlCommand cmdStock = new SqlCommand(sqlStock, cn, tx);
                        cmdStock.Parameters.AddWithValue("@cant", d.Cantidad);
                        cmdStock.Parameters.AddWithValue("@idP", d.IdProducto);

                        int filas = cmdStock.ExecuteNonQuery();
                        if (filas == 0)
                            throw new Exception($"Stock insuficiente para el producto: {d.ProductoNombre}");
                    }

                    // 3. Confirmar toda la transacción
                    tx.Commit();
                }
                catch
                {
                    // 4. Revertir todo si ocurrió cualquier fallo
                    tx.Rollback();
                    throw;
                }
            }
        }

        public List<Venta> ReporteVentasPorFecha(DateTime inicio, DateTime fin)
        {
            List<Venta> lista = new List<Venta>();
            using (SqlConnection cn = Conexion.Instancia.ObtenerConexion())
            {
                SqlCommand cmd = new SqlCommand("sp_ReporteVentasPorFecha", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@FechaInicio", inicio.Date);
                cmd.Parameters.AddWithValue("@FechaFin", fin.Date);

                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    lista.Add(new Venta
                    {
                        IdVenta = Convert.ToInt32(dr["IdVenta"]),
                        NumeroComprobante = dr["NumeroComprobante"].ToString(),
                        Fecha = Convert.ToDateTime(dr["Fecha"]),
                        ClienteNombre = dr["Cliente"].ToString(),
                        VendedorNombre = dr["Vendedor"].ToString(),
                        Total = Convert.ToDecimal(dr["Total"]),
                        Estado = dr["Estado"].ToString()
                    });
                }
            }
            return lista;
        }
    }
}