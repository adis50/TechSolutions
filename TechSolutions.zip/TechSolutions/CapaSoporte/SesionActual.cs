﻿using CapaEntidad;

namespace CapaSoporte
{
    public static class SesionActual
    {
        public static Usuario UsuarioLogueado { get; set; }
    }
}