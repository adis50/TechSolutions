﻿using System.Collections.Generic;
using CapaDatos;
using CapaEntidad;

namespace CapaNegocio
{
    public class ClienteBL
    {
        public List<Cliente> Listar()
        {
            return ClienteDAO.Instancia.Listar();
        }

        public string Registrar(Cliente c)
        {
            if (string.IsNullOrWhiteSpace(c.Documento)) return "Ingrese el documento del cliente.";
            if (string.IsNullOrWhiteSpace(c.Nombres)) return "Ingrese los nombres del cliente.";

            ClienteDAO.Instancia.Insertar(c);
            return "";
        }
    }
}