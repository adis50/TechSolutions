﻿using System;
using System.Collections.Generic;

namespace CapaEntidad
{
    public class Venta
    {
        public int IdVenta { get; set; }
        public string NumeroComprobante { get; set; }
        public DateTime Fecha { get; set; }
        public int IdCliente { get; set; }
        public string ClienteNombre { get; set; }
        public int IdUsuario { get; set; }
        public string VendedorNombre { get; set; }
        public decimal Total { get; set; }
        public string Estado { get; set; }
        public List<DetalleVenta> Detalles { get; set; } = new List<DetalleVenta>();
    }
}