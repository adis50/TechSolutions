﻿using System;
using System.Windows;
using System.Windows.Controls;
using CapaEntidad;
using CapaNegocio;

namespace CapaPresentacion.Vistas
{
    public partial class ProductoWindow : Window
    {
        private readonly ProductoBL _productoBL = new ProductoBL();

        public ProductoWindow()
        {
            InitializeComponent();
            CargarProductos();
        }

        private void CargarProductos(string filtro = "")
        {
            dgProductos.ItemsSource = _productoBL.Listar(filtro);
        }

        private void TxtBuscar_TextChanged(object sender, TextChangedEventArgs e)
        {
            CargarProductos(txtBuscar.Text.Trim());
        }

        private void BtnGuardar_Click(object sender, RoutedEventArgs e)
        {
            if (!decimal.TryParse(txtPrecio.Text, out decimal precio) || !int.TryParse(txtStock.Text, out int stock))
            {
                MessageBox.Show("Ingrese valores numéricos válidos en Precio y Stock.", "Validación", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            Producto nuevo = new Producto
            {
                Codigo = txtCodigo.Text.Trim(),
                Nombre = txtNombre.Text.Trim(),
                Categoria = txtCategoria.Text.Trim(),
                Precio = precio,
                Stock = stock,
                Activo = true
            };

            string error = _productoBL.Registrar(nuevo);
            if (string.IsNullOrEmpty(error))
            {
                MessageBox.Show("Producto registrado correctamente.", "Tech Solutions", MessageBoxButton.OK, MessageBoxImage.Information);
                txtCodigo.Clear();
                txtNombre.Clear();
                txtCategoria.Clear();
                txtPrecio.Clear();
                txtStock.Clear();
                CargarProductos();
            }
            else
            {
                MessageBox.Show(error, "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}