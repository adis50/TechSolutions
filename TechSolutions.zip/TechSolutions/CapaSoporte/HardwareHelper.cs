﻿using System;
using System.Management;

namespace CapaSoporte
{
    public static class HardwareHelper
    {
        public static string ObtenerHardwareId()
        {
            try
            {
                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT ProcessorId FROM Win32_Processor"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        if (obj["ProcessorId"] != null)
                            return obj["ProcessorId"].ToString().Trim();
                    }
                }
            }
            catch
            {
                // Respaldo si WMI está restringido en la PC del laboratorio
            }
            return Environment.MachineName;
        }
    }
}