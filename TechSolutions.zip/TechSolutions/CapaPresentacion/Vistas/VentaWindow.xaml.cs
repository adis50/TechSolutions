﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Threading;
using CapaEntidad;
using CapaNegocio;
using CapaSoporte;

namespace CapaPresentacion.Vistas
{
    public partial class VentaWindow : Window
    {
        private readonly ClienteBL _clienteBL = new ClienteBL();
        private readonly ProductoBL _productoBL = new ProductoBL();
        private readonly VentaBL _ventaBL = new VentaBL();

        private List<DetalleVenta> _carrito = new List<DetalleVenta>();
        private DispatcherTimer _timerReloj;

        public VentaWindow()
        {
            InitializeComponent();
            IniciarTimer();
            PrepararFormulario();
            CargarDatosEnSegundoPlano();
        }

        private void IniciarTimer()
        {
            _timerReloj = new DispatcherTimer();
            _timerReloj.Interval = TimeSpan.FromSeconds(1);
            _timerReloj.Tick += (s, e) =>
            {
                txtRelojTimer.Text = $"Hora del sistema: {DateTime.Now:dd/MM/yyyy HH:mm:ss}  |  Hardware ID: {HardwareHelper.ObtenerHardwareId()}";
            };
            _timerReloj.Start();
        }

        private void PrepararFormulario()
        {
            txtComprobante.Text = "B001-" + DateTime.Now.ToString("mmssff");
            txtVendedor.Text = SesionActual.UsuarioLogueado?.NombreCompleto ?? "Administrador";
            dpInicio.SelectedDate = DateTime.Today.AddDays(-7);
            dpFin.SelectedDate = DateTime.Today;
        }

        private void CargarDatosEnSegundoPlano()
        {
            Thread hiloCarga = new Thread(() =>
            {
                var clientes = _clienteBL.Listar();
                var productos = _productoBL.Listar("");
                var reporteInicial = _ventaBL.ReporteVentas(DateTime.Today.AddDays(-7), DateTime.Today);

                Dispatcher.Invoke(() =>
                {
                    cboCliente.ItemsSource = clientes;
                    cboCliente.DisplayMemberPath = "Nombres";
                    cboCliente.SelectedValuePath = "IdCliente";
                    if (clientes.Count > 0) cboCliente.SelectedIndex = 0;

                    cboProducto.ItemsSource = productos;
                    cboProducto.DisplayMemberPath = "Nombre";
                    cboProducto.SelectedValuePath = "IdProducto";
                    if (productos.Count > 0) cboProducto.SelectedIndex = 0;

                    dgReporteVentas.ItemsSource = reporteInicial;
                });
            });
            hiloCarga.IsBackground = true;
            hiloCarga.Start();
        }

        private void CboProducto_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cboProducto.SelectedItem is Producto prod)
            {
                txtStockDisp.Text = prod.Stock.ToString();
            }
        }

        private void BtnAgregarDetalle_Click(object sender, RoutedEventArgs e)
        {
            if (!(cboProducto.SelectedItem is Producto prod))
            {
                MessageBox.Show("Seleccione un producto.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(txtCantidad.Text, out int cant) || cant <= 0)
            {
                MessageBox.Show("Ingrese una cantidad válida mayor a 0.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var existente = _carrito.FirstOrDefault(d => d.IdProducto == prod.IdProducto);
            if (existente != null)
            {
                existente.Cantidad += cant;
                existente.Subtotal = existente.Cantidad * existente.PrecioUnitario;
            }
            else
            {
                _carrito.Add(new DetalleVenta
                {
                    IdProducto = prod.IdProducto,
                    ProductoNombre = prod.Nombre,
                    Cantidad = cant,
                    PrecioUnitario = prod.Precio,
                    Subtotal = cant * prod.Precio
                });
            }

            RefrescarCarrito();
        }

        private void RefrescarCarrito()
        {
            dgDetalleVenta.ItemsSource = null;
            dgDetalleVenta.ItemsSource = _carrito;
            decimal total = _carrito.Sum(x => x.Subtotal);
            txtTotal.Text = total.ToString("N2");
        }

        private void BtnRegistrarVenta_Click(object sender, RoutedEventArgs e)
        {
            if (!(cboCliente.SelectedItem is Cliente cli))
            {
                MessageBox.Show("Seleccione un cliente.", "Validación", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (_carrito.Count == 0)
            {
                MessageBox.Show("Agregue al menos un producto al carrito.", "Validación", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            Venta nuevaVenta = new Venta
            {
                NumeroComprobante = txtComprobante.Text,
                IdCliente = cli.IdCliente,
                ClienteNombre = cli.Nombres,
                IdUsuario = SesionActual.UsuarioLogueado?.IdUsuario ?? 1,
                VendedorNombre = txtVendedor.Text,
                Total = _carrito.Sum(x => x.Subtotal),
                Detalles = _carrito
            };

            string resultado = _ventaBL.RegistrarVenta(nuevaVenta);

            if (string.IsNullOrEmpty(resultado))
            {
                MessageBox.Show($"Venta {nuevaVenta.NumeroComprobante} registrada con éxito (Commit ejecutado).",
                                "Tech Solutions", MessageBoxButton.OK, MessageBoxImage.Information);

                if (MessageBox.Show("¿Desea imprimir el comprobante de venta?", "Servicio de Impresión",
                                    MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    ImprimirComprobante(nuevaVenta);
                }

                _carrito.Clear();
                RefrescarCarrito();
                txtComprobante.Text = "B001-" + DateTime.Now.ToString("mmssff");
                CargarDatosEnSegundoPlano();
            }
            else
            {
                MessageBox.Show(resultado, "Transacción Revertida (Rollback)", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ImprimirComprobante(Venta v)
        {
            string detalleTexto = string.Join("\n", v.Detalles.Select(d =>
                $"- {d.ProductoNombre}  x{d.Cantidad}  @ S/ {d.PrecioUnitario:N2} = S/ {d.Subtotal:N2}"));

            string contenido =
                "==========================================\n" +
                "           TECH SOLUTIONS S.A.C.          \n" +
                "==========================================\n" +
                $"Comprobante : {v.NumeroComprobante}\n" +
                $"Fecha       : {DateTime.Now:dd/MM/yyyy HH:mm}\n" +
                $"Cliente     : {v.ClienteNombre}\n" +
                $"Vendedor    : {v.VendedorNombre}\n" +
                "------------------------------------------\n" +
                "DETALLE DE PRODUCTOS:\n" +
                detalleTexto + "\n" +
                "------------------------------------------\n" +
                $"TOTAL PAGADO: S/ {v.Total:N2}\n" +
                "==========================================\n";

            PrintDialog printDlg = new PrintDialog();
            if (printDlg.ShowDialog() == true)
            {
                FlowDocument doc = new FlowDocument(new Paragraph(new Run(contenido)));
                doc.PagePadding = new Thickness(40);
                IDocumentPaginatorSource idpSource = doc;
                printDlg.PrintDocument(idpSource.DocumentPaginator, $"Comprobante_{v.NumeroComprobante}");
            }
        }

        private void BtnBuscarReporte_Click(object sender, RoutedEventArgs e)
        {
            DateTime inicio = dpInicio.SelectedDate ?? DateTime.Today;
            DateTime fin = dpFin.SelectedDate ?? DateTime.Today;
            dgReporteVentas.ItemsSource = _ventaBL.ReporteVentas(inicio, fin);
        }
            
        private void BtnImprimirReporte_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog printDlg = new PrintDialog();
            if (printDlg.ShowDialog() == true)
            {
                printDlg.PrintVisual(dgReporteVentas, "Reporte de Ventas - Tech Solutions");
            }
        }
    }
}